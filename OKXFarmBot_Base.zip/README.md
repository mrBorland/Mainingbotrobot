# OKXFarmBot

Бот для фарму на платформах Galxe, OKX, TaskOn з Telegram-інтерфейсом.