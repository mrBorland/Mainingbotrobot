import os, time
from telegram_report import send_report

print("[START] AutoFarmBot — запуск усіх напрямків")
os.system("python modules/crypto/galxe_farm.py")
os.system("python modules/crypto/zealy_farm.py")
os.system("python modules/crypto/layer3_farm.py")
os.system("python modules/taskon/taskon_farm.py")
os.system("python modules/port3/port3_farm.py")
os.system("python modules/questn/questn_farm.py")
os.system("python modules/openblock/openblock_farm.py")
os.system("python modules/passive/passive_income_monitor.py")
os.system("python modules/clickfarm/smart_click_farm_v2.py")
os.system("python modules/youtube/youtube_smart_bot_v3.py")
os.system("python modules/nft/nft_monitor.py")

try:
    with open("modules/youtube/youtube_view_log.txt", "r") as f:
        log_content = f.read()
except:
    log_content = "Немає логів YouTube переглядів."
send_report(f"Звіт AutoFarmBot (усі платформи)

{log_content}")

print("[WAIT] Чекаємо 6 годин до наступного запуску...")
time.sleep(21600)
