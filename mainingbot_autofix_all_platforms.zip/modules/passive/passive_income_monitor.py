# Passive income monitor
print("[Passive] Моніторимо пасивний дохід...")