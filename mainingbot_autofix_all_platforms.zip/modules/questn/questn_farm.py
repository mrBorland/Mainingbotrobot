# QuestN farm logic
print("[QuestN] Фарм QuestN...")