# OpenBlock farm logic
print("[OpenBlock] Фарм OpenBlock...")