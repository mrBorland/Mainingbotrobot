# TaskOn farm logic
print("[TaskOn] Фарм TaskOn...")