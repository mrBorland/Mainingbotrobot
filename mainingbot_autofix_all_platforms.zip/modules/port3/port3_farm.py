# Port3 farm logic
print("[Port3] Фарм Port3...")