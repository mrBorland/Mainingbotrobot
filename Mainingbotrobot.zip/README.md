# Mainingbotrobot
Instructions to use the bot.