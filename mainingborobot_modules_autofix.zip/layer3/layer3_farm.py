import time
print("[Layer3] Запуск фарму...")
time.sleep(2)
print("[Layer3] Layer3 завдання виконані!")