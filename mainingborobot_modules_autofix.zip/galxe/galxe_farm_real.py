import time
print("[Galxe] Старт фарму...")
time.sleep(2)
print("[Galxe] Завдання виконані успішно!")