import time
print("[Zealy] Початок фарму...")
time.sleep(2)
print("[Zealy] Усі Zealy-квести завершено!")