def withdraw_to_wallet(amount, address):
    print(f"[WITHDRAW] Виведено {amount} USDT на {address}")