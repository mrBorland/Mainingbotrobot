import json, requests, logging, time, random

logging.basicConfig(filename="farm_log.txt", level=logging.INFO)

with open("accounts_galxe.json") as f: accounts = json.load(f)
with open("proxies.txt") as f: proxies = f.read().splitlines()

def get_proxy():
    ip, port, user, pwd = random.choice(proxies).split(":")
    return {"http": f"http://{user}:{pwd}@{ip}:{port}", "https": f"http://{user}:{pwd}@{ip}:{port}"}

def farm(account):
    try:
        session = requests.Session()
        session.proxies.update(get_proxy())
        session.headers.update({"User-Agent": "Mozilla/5.0", "Cookie": f"session={account['cookie']}"})
        logging.info(f"[Galxe] Фарм для: {account['email']}")

        session.post("https://api.galxe.com/follow/twitter", json={"username": "example"})
        time.sleep(1)
        session.post("https://api.galxe.com/join/discord", json={"inviteCode": "example"})
        time.sleep(1)
        session.post("https://api.galxe.com/submit/wallet", json={"address": account["wallet"]})

        logging.info(f"[Galxe] Успішно: {account['email']}")
    except Exception as e:
        logging.error(f"[Galxe] Помилка: {account['email']} — {e}")

for acc in accounts:
    farm(acc)
    time.sleep(random.uniform(2, 4))
