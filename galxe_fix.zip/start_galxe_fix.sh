#!/bin/bash
echo "[+] Старт фарму Galxe..."
python galxe_farm_real.py
echo "[+] Надсилаю лог у Telegram..."
python telegram_bot.py
echo "[+] Готово!"
