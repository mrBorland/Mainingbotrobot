import requests

BOT_TOKEN = "7679171745:AAG2ElvAtIWTOG7WQuj7jQWTfQBXx0EUwKI"
CHAT_ID = "6821675571"

with open("farm_log.txt") as f:
    last_lines = f.readlines()[-20:]

message = "Galxe farm log:\n\n" + ''.join(last_lines)
requests.get(f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage", params={"chat_id": CHAT_ID, "text": message})
